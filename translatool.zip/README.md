translatool
===========

export/import PrestaShop strings to translate them with external programs
